def find(value,list):
	x = value 
	if x in list:
		return list.index(x), x

def findbool(value,list):
	x = value 
	if x in list:
		return True 